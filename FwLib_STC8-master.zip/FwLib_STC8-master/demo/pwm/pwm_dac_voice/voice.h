#include "fw_hal.h"

extern __CODE uint8_t voice_bulk[];